import sqlite3 from 'sqlite3';
import { open, Database } from 'sqlite';
import path from 'path';
import fs from 'fs';

let dbInstance: Database | null = null;

export async function getDb(): Promise<Database> {
  if (dbInstance) {
    return dbInstance;
  }

  const dbDir = path.join(process.cwd(), 'data');
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  const dbPath = path.join(dbDir, 'caregiver.db');

  dbInstance = await open({
    filename: dbPath,
    driver: sqlite3.Database,
  });

  // Initialize schema
  await initSchema(dbInstance);

  return dbInstance;
}

async function initSchema(db: Database) {
  // Enable foreign keys
  await db.run('PRAGMA foreign_keys = ON;');

  // 1. CG_FAMILY: 가족방
  await db.exec(`
    CREATE TABLE IF NOT EXISTS CG_FAMILY (
      FAMILY_ID TEXT PRIMARY KEY,
      FAMILY_NAME TEXT NOT NULL,
      CREATED_AT DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // 2. CG_USER: 사용자 테이블 (부모/자녀 공통)
  await db.exec(`
    CREATE TABLE IF NOT EXISTS CG_USER (
      USER_ID TEXT PRIMARY KEY,
      FAMILY_ID TEXT,
      USER_NAME TEXT NOT NULL,
      ROLE TEXT NOT NULL CHECK(ROLE IN ('LEADER', 'MEMBER', 'CHILD')),
      PHONE_NUMBER TEXT,
      CREATED_AT DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (FAMILY_ID) REFERENCES CG_FAMILY(FAMILY_ID)
    );
  `);

  // 3. CG_CARE_PROFILE: 부모님 상태 프로필 (계산용)
  await db.exec(`
    CREATE TABLE IF NOT EXISTS CG_CARE_PROFILE (
      PROFILE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
      FAMILY_ID TEXT NOT NULL,
      AGE INTEGER NOT NULL,
      REGION TEXT NOT NULL,
      DISEASE_STATE TEXT NOT NULL,
      INCOME_LEVEL TEXT NOT NULL,
      EXPECTED_CARE_TYPE TEXT NOT NULL,
      CREATED_AT DATETIME DEFAULT CURRENT_TIMESTAMP,
      UPDATED_AT DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (FAMILY_ID) REFERENCES CG_FAMILY(FAMILY_ID)
    );
  `);

  // 4. CG_MISSION_POOL: 미션 목록
  await db.exec(`
    CREATE TABLE IF NOT EXISTS CG_MISSION_POOL (
      MISSION_ID INTEGER PRIMARY KEY AUTOINCREMENT,
      FAMILY_ID TEXT NOT NULL,
      MISSION_NAME TEXT NOT NULL,
      POINTS INTEGER NOT NULL,
      CREATED_BY TEXT,
      CREATED_AT DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (FAMILY_ID) REFERENCES CG_FAMILY(FAMILY_ID),
      FOREIGN KEY (CREATED_BY) REFERENCES CG_USER(USER_ID)
    );
  `);

  // 5. CG_MISSION_REG: 자녀 미션 수행 기록
  await db.exec(`
    CREATE TABLE IF NOT EXISTS CG_MISSION_REG (
      REG_ID INTEGER PRIMARY KEY AUTOINCREMENT,
      MISSION_ID INTEGER NOT NULL,
      CHILD_ID TEXT NOT NULL,
      STATUS TEXT DEFAULT 'REQUESTED' CHECK(STATUS IN ('REQUESTED', 'APPROVED', 'REJECTED')),
      CHILD_COMMENT TEXT,
      APPROVED_BY TEXT,
      REQUESTED_AT DATETIME DEFAULT CURRENT_TIMESTAMP,
      APPROVED_AT DATETIME,
      FOREIGN KEY (MISSION_ID) REFERENCES CG_MISSION_POOL(MISSION_ID),
      FOREIGN KEY (CHILD_ID) REFERENCES CG_USER(USER_ID),
      FOREIGN KEY (APPROVED_BY) REFERENCES CG_USER(USER_ID)
    );
  `);

  // 6. CG_WALLET: 자녀 지갑 장부
  await db.exec(`
    CREATE TABLE IF NOT EXISTS CG_WALLET (
      CHILD_ID TEXT PRIMARY KEY,
      CURRENT_POINTS INTEGER DEFAULT 0,
      TOTAL_EARNED INTEGER DEFAULT 0,
      TARGET_POINTS INTEGER DEFAULT 10000,
      TARGET_ITEM TEXT DEFAULT '닌텐도 스위치 칩',
      UPDATED_AT DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (CHILD_ID) REFERENCES CG_USER(USER_ID)
    );
  `);

  // 7. CG_CALENDAR: 가족 일정
  await db.exec(`
    CREATE TABLE IF NOT EXISTS CG_CALENDAR (
      EVENT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
      FAMILY_ID TEXT NOT NULL,
      EVENT_DATE TEXT NOT NULL,
      EVENT_TIME TEXT NOT NULL,
      TITLE TEXT NOT NULL,
      DESCRIPTION TEXT,
      ASSIGNEE_ID TEXT,
      STATUS TEXT DEFAULT 'PENDING',
      CREATED_AT DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (FAMILY_ID) REFERENCES CG_FAMILY(FAMILY_ID),
      FOREIGN KEY (ASSIGNEE_ID) REFERENCES CG_USER(USER_ID)
    );
  `);

  // 8. CG_EXPENSE: 정산 장부
  await db.exec(`
    CREATE TABLE IF NOT EXISTS CG_EXPENSE (
      EXPENSE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
      FAMILY_ID TEXT NOT NULL,
      TITLE TEXT NOT NULL,
      PAYER_ID TEXT NOT NULL,
      AMOUNT INTEGER NOT NULL,
      EXPENSE_DATE TEXT NOT NULL,
      IS_SETTLED INTEGER DEFAULT 0,
      CREATED_AT DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (FAMILY_ID) REFERENCES CG_FAMILY(FAMILY_ID),
      FOREIGN KEY (PAYER_ID) REFERENCES CG_USER(USER_ID)
    );
  `);

  // Seed default data if database is brand new
  const familyCount = await db.get('SELECT COUNT(*) as count FROM CG_FAMILY');
  if (familyCount && familyCount.count === 0) {
    const defaultFamilyId = 'FAM-DJE-2026';
    await db.run(
      'INSERT INTO CG_FAMILY (FAMILY_ID, FAMILY_NAME) VALUES (?, ?)',
      defaultFamilyId,
      '김씨네 가족돌봄방'
    );

    // Seed users
    // Leader / Parent
    await db.run(
      'INSERT INTO CG_USER (USER_ID, FAMILY_ID, USER_NAME, ROLE, PHONE_NUMBER) VALUES (?, ?, ?, ?, ?)',
      'u1', defaultFamilyId, '대장님(나)', 'LEADER', '010-1234-5678'
    );
    await db.run(
      'INSERT INTO CG_USER (USER_ID, FAMILY_ID, USER_NAME, ROLE, PHONE_NUMBER) VALUES (?, ?, ?, ?, ?)',
      'u2', defaultFamilyId, '첫째 오빠', 'MEMBER', '010-8765-4321'
    );
    await db.run(
      'INSERT INTO CG_USER (USER_ID, FAMILY_ID, USER_NAME, ROLE, PHONE_NUMBER) VALUES (?, ?, ?, ?, ?)',
      'u3', defaultFamilyId, '막내 동생', 'MEMBER', '010-1111-2222'
    );

    // Child
    const childId = 'c1';
    await db.run(
      'INSERT INTO CG_USER (USER_ID, FAMILY_ID, USER_NAME, ROLE) VALUES (?, ?, ?, ?)',
      childId, defaultFamilyId, '11살 아들', 'CHILD'
    );

    // Initialize Child Wallet
    await db.run(
      'INSERT INTO CG_WALLET (CHILD_ID, CURRENT_POINTS, TOTAL_EARNED, TARGET_POINTS, TARGET_ITEM) VALUES (?, ?, ?, ?, ?)',
      childId, 49500, 49500, 50000, '닌텐도 스위치 칩'
    );

    // Seed default missions
    await db.run(
      'INSERT INTO CG_MISSION_POOL (FAMILY_ID, MISSION_NAME, POINTS, CREATED_BY) VALUES (?, ?, ?, ?)',
      defaultFamilyId, '수학 익힘책 5장 풀기', 700, 'u1'
    );
    await db.run(
      'INSERT INTO CG_MISSION_POOL (FAMILY_ID, MISSION_NAME, POINTS, CREATED_BY) VALUES (?, ?, ?, ?)',
      defaultFamilyId, '분리수거 돕기', 500, 'u1'
    );

    // Seed a mission waiting for approval
    const activeMissionId = 3;
    await db.run(
      "INSERT INTO CG_MISSION_POOL (MISSION_ID, FAMILY_ID, MISSION_NAME, POINTS, CREATED_BY) VALUES (?, ?, ?, ?, ?)",
      activeMissionId, defaultFamilyId, '할머니께 안부 전화드리기', 1000, 'u1'
    );
    await db.run(
      'INSERT INTO CG_MISSION_REG (MISSION_ID, CHILD_ID, STATUS, CHILD_COMMENT) VALUES (?, ?, ?, ?)',
      activeMissionId, childId, 'REQUESTED', '오늘 할머니가 주말에 맛있는 거 사주신대요!'
    );

    // Seed default calendar event
    await db.run(
      'INSERT INTO CG_CALENDAR (FAMILY_ID, EVENT_DATE, EVENT_TIME, TITLE, DESCRIPTION, STATUS) VALUES (?, ?, ?, ?, ?, ?)',
      defaultFamilyId, '2026-03-15', '14:00', '충남대병원 치매안심센터 정기 검사', '신분증, 이전 처방전 지참 필수', 'PENDING'
    );

    // Seed default expense
    await db.run(
      'INSERT INTO CG_EXPENSE (FAMILY_ID, TITLE, PAYER_ID, AMOUNT, EXPENSE_DATE, IS_SETTLED) VALUES (?, ?, ?, ?, ?, ?)',
      defaultFamilyId, '어머님 치매 약값 (3개월치)', 'u2', 300000, '3월 10일', 0
    );
  }
}
